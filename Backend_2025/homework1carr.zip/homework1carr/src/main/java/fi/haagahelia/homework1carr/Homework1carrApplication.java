package fi.haagahelia.homework1carr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Homework1carrApplication {

	public static void main(String[] args) {
		SpringApplication.run(Homework1carrApplication.class, args);
	}

}
